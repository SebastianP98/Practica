# Practica
 Make a file Practica on Desktop, download git and go to Desktop/Practica.
 Next do $git clone https://github.com/SebastianP98/Practica/
 
